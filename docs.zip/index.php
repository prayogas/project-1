<?php
session_start();
header('location:template.php?pages=home');
?>